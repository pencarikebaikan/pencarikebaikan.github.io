---
layout: page
title: About
description: Some description.
permalink: /about/
---

<img itemprop="image" class="img-rounded" src="https://res.cloudinary.com/dkctvgb09/image/upload/c_fill,h_200,w_180/v1563607469/florist-3237905_1920_y59iqn.jpg" alt="Your Name">

## About

앱 서비스에 관심있는 학생입니다. 
