---
layout: default
permalink: /contact/message-sent/
---

<style type="text/css" media="screen">
  .container {
    margin: 0px auto;
    max-width: 600px;
    text-align: center;
    padding-top: 60px;
  }
</style>

<div class="container">
  <img src="/assets/img/message.gif" width="540" alt="Message sent!">
  <p><strong>Message sent!</strong></p>
  <p>Thank you for sending me a message. I'm going to answer ASAP.</p>
</div>
